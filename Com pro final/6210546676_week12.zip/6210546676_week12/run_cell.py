# from cell import *


# c1 = Cell(1,2,True)
# print(c1)
# print(c1.occupy_list)

from cell import *
from player import *
c1 = Cell(1,2,True)
print(c1)
a = Player('A')
b = Player('B')
print(a)
print(b)