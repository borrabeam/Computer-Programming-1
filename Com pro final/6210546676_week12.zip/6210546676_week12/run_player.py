from player import *
a = Player('A')
b = Player('B')
print(a)
print(b)