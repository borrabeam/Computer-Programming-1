import random
from player import *
class Team:
def __init__(self, filename, team_name='No Name'):
    self.__player_list = self.__read_team(filename)

def __read_team(self, filename):
    player_list = []
    lines = open(filename).read().splitlines()
    table = []
    for x in lines:
        if x != ''
            table.append(x.split(','))
    for row in table:
        team_player = Player(name,num_wins,num_plays)
        player_list.append(team_player)

    return player_list
def __str__(self):
